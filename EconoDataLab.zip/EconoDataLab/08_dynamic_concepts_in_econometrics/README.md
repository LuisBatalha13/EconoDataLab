# Dynamic Concepts in Econometrics
Econophysics analogies: overdamped, underdamped, critically damped + memory.
