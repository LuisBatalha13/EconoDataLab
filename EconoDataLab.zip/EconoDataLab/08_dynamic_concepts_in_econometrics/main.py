"""08 - Dynamic Concepts in Econometrics
Author: Frater LuisBatalha Animus
Goal: Demonstrate concept using simulated impulse response with damping and short/long memory.
"""
import numpy as np
import matplotlib.pyplot as plt

def damped_response(t, omega=1.0, zeta=0.5):
    # zeta = damping ratio: <1 underdamped, =1 critical, >1 overdamped
    wd = omega * np.sqrt(max(0, 1 - zeta**2))
    A = 1.0
    if zeta < 1.0:
        return A * np.exp(-zeta*omega*t) * np.cos(wd * t)
    elif np.isclose(zeta, 1.0):
        return A * np.exp(-omega*t) * (1 + omega*t)
    else:
        r1 = -omega*(zeta - np.sqrt(zeta**2 -1))
        r2 = -omega*(zeta + np.sqrt(zeta**2 -1))
        return A * (np.exp(r1*t) - np.exp(r2*t))

t = np.linspace(0, 20, 400)
resp_under = damped_response(t, omega=1.0, zeta=0.3)
resp_crit = damped_response(t, omega=1.0, zeta=1.0)
resp_over = damped_response(t, omega=1.0, zeta=1.5)

plt.figure(figsize=(8,4))
plt.plot(t, resp_under, label='Underdamped (volatile economy)')
plt.plot(t, resp_crit, label='Critically damped (well-managed)')
plt.plot(t, resp_over, label='Overdamped (slow adjust)')
plt.legend()
plt.title('Econophysics: Damped Responses to Shocks')
plt.xlabel('Time')
plt.ylabel('Response')
plt.grid(True)
plt.show()

# Short vs Long memory demonstration (Hurst exponent idea)
def hurst_exponent(ts):
    N = len(ts)
    T = np.arange(1, N+1)
    Y = np.cumsum(ts - np.mean(ts))
    R = np.maximum.accumulate(Y) - np.minimum.accumulate(Y)
    S = np.std(ts)
    RS = (R / S)[-1]
    return np.log(RS) / np.log(N)

short_series = np.random.randn(1000)
long_series = np.cumsum(np.random.randn(1000))  # integrated -> long memory flavor

print('Hurst approx short series:', hurst_exponent(short_series))
print('Hurst approx long series:', hurst_exponent(long_series))
