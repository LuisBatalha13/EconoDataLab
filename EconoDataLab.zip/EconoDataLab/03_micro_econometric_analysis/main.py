"""03 - Micro Econometric Analysis
Author: Frater LuisBatalha Animus
Goal: Run an OLS regression for firm-level demand estimation.
"""
import pandas as pd
import statsmodels.api as sm

data = pd.DataFrame({
    'price': [10, 12, 15, 20, 25, 30],
    'income': [2000, 2500, 3000, 3500, 4000, 4500],
    'quantity': [500, 480, 460, 420, 400, 380]
})

X = data[['price', 'income']]
y = data['quantity']
X = sm.add_constant(X)
model = sm.OLS(y, X).fit()
print(model.summary())
