"""05 - Causal Inference (DiD)
Author: Frater LuisBatalha Animus
Goal: Implement a Difference-in-Differences model for policy impact analysis.
"""
import pandas as pd
import statsmodels.formula.api as smf

df = pd.DataFrame({
    'group': [0,0,1,1]*2,
    'time': [0,1,0,1]*2,
    'outcome': [5,6,5,9,4,5,4,8]
})
df['treat'] = (df['group']==1).astype(int)
df['post'] = (df['time']==1).astype(int)
df['did'] = df['treat'] * df['post']
model = smf.ols('outcome ~ treat + post + did', data=df).fit()
print(model.summary())
