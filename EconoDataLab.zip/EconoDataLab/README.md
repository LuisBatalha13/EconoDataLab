# 📊 EconoDataLab
**Economic Modeling, Forecasting & Analytics**

Repositório com 8 projetos de econometria, machine learning e análise de dados aplicados a questões macro e microeconômicas, com foco em mercados emergentes e países da SADC.

## 📂 Projects
1. Previsão Macroeconômica com VAR/VECM
2. Modelos Estruturais (SVAR) para Choques Econômicos
3. Preços de Commodities com Machine Learning
4. Elasticidade e Sensibilidade de Variáveis Econômicas
5. Previsão Microeconômica de Vendas Empresariais
6. Nowcasting Econômico
7. Análise de Impacto de Políticas Públicas
8. Econofísica e Memória Econômica

## 🛠 Requirements
Install dependencies:
```
pip install -r requirements.txt
```

## 📜 License
MIT License – Free for professional and academic use.
