"""07 - Econometric Policy Simulation
Author: Frater LuisBatalha Animus
Goal: Simulate counterfactual scenarios using regression model.
"""
import pandas as pd
import numpy as np
import statsmodels.api as sm

np.random.seed(42)
df = pd.DataFrame({
    'gdp_growth': np.random.randn(20) + 2,
    'interest_rate': np.random.rand(20) * 5
})
X = sm.add_constant(df['interest_rate'])
y = df['gdp_growth']
model = sm.OLS(y, X).fit()
cf_X = sm.add_constant(pd.Series([2]*20))
cf_pred = model.predict(cf_X)
print('Counterfactual GDP growth sample:')
print(cf_pred.head())
