# Panel Data Analysis
Fixed/Random Effects examples.
