"""04 - Panel Data Analysis
Author: Frater LuisBatalha Animus
Goal: Demonstrate Fixed Effects model using synthetic panel data.
"""
import pandas as pd
import numpy as np
from linearmodels.panel import PanelOLS

np.random.seed(42)
n = 5; t = 4
df = pd.DataFrame({
    'entity': np.repeat(range(n), t),
    'time': list(range(t)) * n,
    'y': np.random.randn(n * t) + 5,
    'x1': np.random.randn(n * t)
})
df = df.set_index(['entity', 'time'])
model = PanelOLS.from_formula('y ~ x1 + EntityEffects', data=df)
results = model.fit()
print(results.summary)
