"""06 - Forecasting with Machine Learning
Author: Frater LuisBatalha Animus
Goal: Predict economic variable using XGBoost.
"""
import numpy as np
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

np.random.seed(42)
X = np.random.rand(200, 5)
y = X[:,0]*3 + X[:,1]*-2 + np.random.randn(200)*0.1
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = XGBRegressor(n_estimators=50, verbosity=0)
model.fit(X_train, y_train)
preds = model.predict(X_test)
print('RMSE:', mean_squared_error(y_test, preds, squared=False))
