"""02 - Macro Econometric Modeling
Author: Frater LuisBatalha Animus
Goal: Build a VAR model using GDP and CPI.
"""
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.api import VAR

data = sm.datasets.macrodata.load_pandas().data
data.index = pd.date_range(start='1959Q1', periods=len(data), freq='Q')
df = data[['realgdp', 'cpi']].dropna()

model = VAR(df)
results = model.fit(maxlags=4, ic='aic')
print(results.summary())
forecast = results.forecast(df.values[-results.k_ar:], steps=8)
print('VAR forecast shape:', forecast.shape)
