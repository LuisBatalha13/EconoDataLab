# Macro Econometric Modeling
VAR/VECM examples.
