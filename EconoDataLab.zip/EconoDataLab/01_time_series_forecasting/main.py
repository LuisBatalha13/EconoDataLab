"""01 - Time Series Forecasting
Author: Frater LuisBatalha Animus
Goal: Demonstrate ARIMA forecasting for economic time series.
"""
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt

# Load example macro dataset
data = sm.datasets.macrodata.load_pandas().data
data.index = pd.date_range(start='1959Q1', periods=len(data), freq='Q')
gdp = data['realgdp']

model = sm.tsa.ARIMA(gdp, order=(1,1,1))
results = model.fit()
forecast = results.get_forecast(steps=8)
ci = forecast.conf_int()

plt.figure(figsize=(8,5))
plt.plot(gdp, label='Observed')
plt.plot(forecast.predicted_mean, label='Forecast')
plt.fill_between(ci.index, ci.iloc[:,0], ci.iloc[:,1], alpha=0.2)
plt.legend()
plt.title('GDP Forecast (ARIMA)')
plt.show()
